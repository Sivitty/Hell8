./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RFnJCgfXBLoKVweH32X2ABuqFxiMdY3gDD.hell -p x --cpu 8
